﻿using Microsoft.AspNetCore.Mvc;

namespace Aula_30_dia_15_07.Models
{
    public class Aluno
    {
        public int id { get; set; }

        public string nome { get; set; }
        public string sobrenome{ get; set; }
    }
}
